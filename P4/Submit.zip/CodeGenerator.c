#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>
#include<math.h>
#define ll long long
#define ull unsigned long long
#define db double
#define gc getchar()
#define rd read()
#define fr frd(src)
#define max(a,b) (a)>(b)?(a):(b)
#define min(a,b) (a)<(b)?(a):(b)

#define MAX_INSTRUMENT 7
#define MAX_RegPool 10

int RegPool[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

int main() {
    srand(time(NULL));
    FILE *fp = fopen("code.asm", "w");
    for (int i = 0; i < 1000; i++) {
        int temp = rand() % MAX_INSTRUMENT;
        fprintf(fp, "LABEL%03d: ", i);
        switch(temp) {
            case 0 : fprintf(fp, "addu ");
                     fprintf(fp, "$%d, $%d, $%d\n", RegPool[rand() % MAX_RegPool], RegPool[rand() % MAX_RegPool], RegPool[rand() % MAX_RegPool]);
                     break;
            case 1 : fprintf(fp, "subu ");
                     fprintf(fp, "$%d, $%d, $%d\n", RegPool[rand() % MAX_RegPool], RegPool[rand() % MAX_RegPool], RegPool[rand() % MAX_RegPool]);
                     break;
            case 2 : fprintf(fp, "lui ");
                     fprintf(fp, "$%d, %d\n", RegPool[rand() % MAX_RegPool], RegPool[rand() % MAX_RegPool], rand() % 32000);
                     break;
            case 3 : fprintf(fp, "sw ");
                fprintf(fp, "$%d, %d($%d)\n", RegPool[rand() % MAX_RegPool], (rand() % 20) * 4, 0);
                break;
            case 4 : fprintf(fp, "lw ");
                fprintf(fp, "$%d, %d($%d)\n", RegPool[rand() % MAX_RegPool], (rand() % 20) * 4, 0);
                break;
            case 5 : fprintf(fp, "beq "); 
                if (rand() % 2)
                    fprintf(fp, "$%d, $%d, LABEL%03d\n", RegPool[rand() % MAX_RegPool], 0, i + 1 + (rand() % (999 - i)) % 10);
                else
                    fprintf(fp, "$0, $0, LABEL%03d\n", i + 1 + (rand() % (999 - i)) % 10);
                     break;
            case 6 : fprintf(fp, "jal ");
                    fprintf(fp, "LABEL%03d\n", i + 1 + (rand() % (999 - i)) % 10);
                    break;
            case 7 : fprintf(fp, ""); 
                     
                     break;
            case 8 : fprintf(fp, ""); 
                     
                     break;
            default: fprintf(fp, "nop\n"); 
                     
                     break;
        }
    }
        return 0;
}